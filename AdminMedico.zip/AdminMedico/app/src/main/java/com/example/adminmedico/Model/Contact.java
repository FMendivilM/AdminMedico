package com.example.adminmedico.Model;

public class Contact {
    public  int id;
    public String name;
    public String phone;
    public String email;

    public Contact() {

    }

    public Contact(String email, String phone, String name, int id) {
        this.email = email;
        this.phone = phone;
        this.name = name;
        this.id = id;
    }

    public Contact(String nombre, String telefono, String email) {
        super();
        this.name = nombre;
        this.phone = telefono;
        this.email = email;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return this.name;
    }
}
